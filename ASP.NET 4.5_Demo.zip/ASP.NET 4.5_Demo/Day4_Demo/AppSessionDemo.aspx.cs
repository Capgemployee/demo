﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AppSessionDemo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Write("<h2> No of active user :" + Application["appCnt"].ToString() + "</h2>");
        Response.Write("<h2> You are watching this Page :" + Session["sesCnt"].ToString() +"Times</h2>");
        if (!IsPostBack)
        {

        }
        else 
        {
            Session["sesCnt"] = Convert.ToInt32(Session["sesCnt"]) + 1;
        }
   
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

    }
}