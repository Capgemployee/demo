﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CokkieResult : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        HttpCookie newCk = Request.Cookies["CookieDemo"];
        Label1.Text =  newCk.Values["FName"].ToString()+ " "+ newCk.Values["LName"].ToString();
    }
}