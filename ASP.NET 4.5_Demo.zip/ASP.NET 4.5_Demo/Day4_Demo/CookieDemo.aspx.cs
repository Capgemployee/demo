﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CookieDemo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        HttpCookie myCookie = new HttpCookie("CookieDemo");
        myCookie.Values.Add("FName", TextBox1.Text);
        myCookie.Values.Add("LName", "Sharma");
      //  myCookie.Value = TextBox1.Text;
       // myCookie.Expires = DateTime.Now.AddDays(30);
        myCookie.Expires = DateTime.Now.AddMinutes(5d);
        Response.Cookies.Add(myCookie);
        Response.Redirect("CokkieResult.aspx");
    }
}