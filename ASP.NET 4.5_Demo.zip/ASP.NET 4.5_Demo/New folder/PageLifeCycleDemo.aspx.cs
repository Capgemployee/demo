﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PageLifeCycleDemo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Write("<br> We are Page load event </br>");
    }
    protected void Page_PreInIt(object sender, EventArgs e)
    {
        Response.Write("<br> We are Page PreInIt event </br>");
    }
    protected void Page_InIt(object sender, EventArgs e)
    {
        Response.Write("<br> We are Page Init event </br>");
    }
    protected void Page_PreRender(object sender, EventArgs e)
    {
        Response.Write("<br> We are Page PreRender event </br>");
    }
}