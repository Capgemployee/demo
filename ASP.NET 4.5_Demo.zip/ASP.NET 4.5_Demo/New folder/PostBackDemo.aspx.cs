﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PostBackDemo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Write("<h1>Is it a Post Back : " +IsPostBack.ToString()+"</h1>");
        if (!IsPostBack)
        {
            DropDownList1.Items.Add("pune");
            DropDownList1.Items.Add("Mumbai");
            DropDownList1.Items.Add("Hydrabad");
            DropDownList1.Items.Add("Bangalore");
        }
    }

    protected void Button1_Click(object sender, EventArgs e) //server side button
    {
        Response.Write("Welcome " + TextBox1.Text + "<br> You lives in : </br>" + DropDownList1.SelectedItem.Text);
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Response.Write("Welcome " + TextBox1.Text + "<br> You lives in : </br>" + DropDownList1.SelectedItem.Text);
    }
}