﻿using System;
using System.Collections.Generic;
using System.Web;

/// <summary>
/// Summary description for Student
/// </summary>
public class Student
{
    int rollNo;
    string address;
    string name;

public int RollNo
{
  get { return rollNo; }
  set { rollNo = value; }
}
    

public string Address
{
  get { return address; }
  set { address = value; }
}
   

public string Name
{
  get { return name; }
  set { name = value; }
}

	public Student()
	{
        
		//
		// TODO: Add constructor logic here
		//
	}
}