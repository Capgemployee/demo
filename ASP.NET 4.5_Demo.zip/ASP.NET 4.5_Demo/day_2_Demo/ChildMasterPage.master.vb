﻿
Partial Class ChildMasterPage
    Inherits System.Web.UI.MasterPage
End Class

