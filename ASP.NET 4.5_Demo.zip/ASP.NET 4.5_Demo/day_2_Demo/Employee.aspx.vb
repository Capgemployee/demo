﻿
Partial Class Employee
    Inherits System.Web.UI.Page

End Class
