﻿
Partial Class MainMasterPage
    Inherits System.Web.UI.MasterPage
End Class

