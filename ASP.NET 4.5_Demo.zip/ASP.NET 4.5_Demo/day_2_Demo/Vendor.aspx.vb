﻿
Partial Class Vendor
    Inherits System.Web.UI.Page

End Class
