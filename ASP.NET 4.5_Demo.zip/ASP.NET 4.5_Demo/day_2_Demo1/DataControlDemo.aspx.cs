﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DataControlDemo : System.Web.UI.Page
{
    string[] city = new string[] { "Pune", "Mumbai", "Bangalore", "Delhi" , "Bhumneshwar" };
    protected void Page_Load(object sender, EventArgs e)
    {
        BulletedList1.DataSource = city;
        RadioButtonList1.DataSource = city;
        ListBox1.DataSource = city;
        DropDownList1.DataSource = city;
        CheckBoxList1.DataSource = city;

        Page.DataBind();

    }
}