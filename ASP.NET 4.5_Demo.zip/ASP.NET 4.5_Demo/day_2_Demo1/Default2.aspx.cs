﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Default2 : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataReader sdr;

    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection();
        con.ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_18Jan2017_Talwade;User ID=sqluser;Password=sqluser;";
        con.Open();
        //Initializing command
        cmd = new SqlCommand();
        cmd.CommandText = "Select* from Students";
        cmd.CommandType = CommandType.Text;
        cmd.Connection = con;
        //hold the result on client side
        sdr = cmd.ExecuteReader();
        sdr.Read();
        //putting data in to Table
        DataTable myDt = new DataTable();
        myDt.Load(sdr);
        GridView1.DataSource = myDt;   //this binding data
        GridView1.DataBind();
        con.Close();

    }
}