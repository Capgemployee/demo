﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ddlcountry.Items.Add("India");
            ddlcountry.Items.Add("US");
            ddlstate.Items.Add("State");
            ddlcity.Items.Add("City");
        }
        
    }
    protected void ddlcountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlstate.Items.Clear();
        ddlcity.Items.Clear();
        if (ddlcountry.SelectedItem.Text != null)
        {
            if (ddlcountry.SelectedItem.Text == "US")
            {
                ddlstate.Items.Add("California");
                ddlstate.Items.Add("Texas");
            }
            else
            {
                ddlstate.Items.Add("Maharashtra");
                ddlstate.Items.Add("MadhyaPradesh");
            }
        }
    }
    protected void ddlstate_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlcity.Items.Clear();
        if (ddlstate.SelectedItem.Text == "Maharashtra")
        {
            ddlcity.Items.Add("Mumbai");
            ddlcity.Items.Add("Pune");
        }
        else if (ddlstate.SelectedItem.Text == "MadhyaPradesh")
        {
            ddlcity.Items.Add("Bhopal");
            ddlcity.Items.Add("Indore");
        }

        else if (ddlstate.SelectedItem.Text == "California")
        {
            ddlcity.Items.Add("Washington DC");
            ddlcity.Items.Add("NewYork City");
        }
        else if (ddlstate.SelectedItem.Text == "Texas")
        {
            ddlcity.Items.Add("Dallas");
            ddlcity.Items.Add("Plano");
        }

    }
}