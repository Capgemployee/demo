﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ddlCountry.Items.Add("India");
            ddlCountry.Items.Add("US");
            ddlState.Items.Add("State");
            ddlCity.Items.Add("City");
        }
    }
    protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCountry.SelectedItem.Text== "India")
        {
            ddlState.Items.Add("Maharashta");
            ddlState.Items.Add("MadhyaPradesh");
        }
        if (ddlCountry.SelectedItem.Text == "US")
        {
            ddlState.Items.Add("California");
            ddlState.Items.Add("Texas");
        }


    }
    //protected void ddlState_SelectedIndexChanged1(object sender, EventArgs e)
    //{
    //    if (ddlState.SelectedItem.Text == "Maharashtra") 
    //    {
    //        ddlCity.Items.Add("Mumbai");
    //        ddlCity.Items.Add("Pune");
    //    }
    //    if (ddlState.SelectedItem.Text == "MadhyaPradesh")
    //    {
    //        ddlCity.Items.Add("Bhopal");
    //        ddlCity.Items.Add("Indore");

    //    }
    //    if (ddlState.SelectedItem.Text == "California")
    //    {
    //        ddlCity.Items.Add("Washington DC");
    //        ddlCity.Items.Add("NewYork City");
    //    }
    //    if (ddlState.SelectedItem.Text == " Texas")
    //    {
    //        ddlCity.Items.Add("Dallas");
    //        ddlCity.Items.Add("Plano");
    //    }
    //}



    protected void ddlCity_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlState.SelectedItem.Text == "Maharashtra")
        {
            ddlCity.Items.Add("Mumbai");
            ddlCity.Items.Add("Pune");
        }
        if (ddlState.SelectedItem.Text == "MadhyaPradesh")
        {
            ddlCity.Items.Add("Bhopal");
            ddlCity.Items.Add("Indore");

        }
        if (ddlState.SelectedItem.Text == "California")
        {
            ddlCity.Items.Add("Washington DC");
            ddlCity.Items.Add("NewYork City");
        }
        if (ddlState.SelectedItem.Text == " Texas")
        {
            ddlCity.Items.Add("Dallas");
            ddlCity.Items.Add("Plano");
        }

    }
    protected void ddlState_SelectedIndexChanged1(object sender, EventArgs e)
    {

    }
}