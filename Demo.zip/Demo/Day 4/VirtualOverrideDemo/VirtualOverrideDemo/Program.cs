﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VirtualOverrideDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Manager mgr = new Manager();
            mgr.Show();

            Employee empMgr = new Manager();
            empMgr.Show();
        }
    }
}
