﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousMethodDemo
{
    public delegate void AnonymousDelegate();

    class Program
    {
        public static void Display()
        {
            Console.WriteLine("Display Method is called");
        }

        static void Main(string[] args)
        {
            AnonymousDelegate del = delegate 
            {
                Console.WriteLine("Anonymous Method is called");
            };

            del();

            Console.ReadKey();
        }
    }
}
