﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousMethodwithReturn
{
    public delegate int MathDeleagate(int num1, int num2);
    class Program
    {
        static void Main(string[] args)
        {
            MathDeleagate del = delegate(int num1, int num2) 
            {
                return num1 + num2;
            };

            Console.WriteLine(del(23, 56));

            Console.ReadKey();
        }
    }
}
