using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingCart.BL
{
    class RegistrationControl
    {
    }
}
